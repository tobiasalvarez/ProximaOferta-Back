package com.example.proximaOferta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProximaOfertaApplicationTests {

	@Test
	void contextLoads() {
	}

}
