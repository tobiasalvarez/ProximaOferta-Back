package com.example.proximaOferta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProximaOfertaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProximaOfertaApplication.class, args);
	}

}
